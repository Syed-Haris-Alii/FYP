import logo from './logo/logo_01.png';
import logo2 from './logo/logo_02.png';
import logo3 from './logo/logo_03.png';

import lazy from './lazy.svg';
import img_01 from './assets/img_01.jpg'
import img_02 from './assets/img_02.jpg'
import img_03 from './assets/img_03.jpg'
import img_04 from './assets/img_04.jpg'

import img_09 from './assets/img_09.png'

import screen_01 from './assets/screen_01.png'
import screen_02 from './assets/screen_02.png'
import screen_03 from './assets/screen_03.png'
import shape_1 from './shape/shape_01.svg'
import shape_2 from './shape/shape_02.svg'
import shape_3 from './shape/shape_03.svg'
import shape_7 from './shape/shape_07.svg'
import shape_8 from './shape/shape_08.svg'
import shape_9 from './shape/shape_09.svg'
import shape_10 from './shape/shape_10.svg'
import shape_12 from './shape/shape_12.svg'
import shape_13 from './shape/shape_13.svg'
import shape_14 from './shape/shape_14.svg'
import icon_8 from './shape/icon_08.svg'
import icon_9 from './shape/icon_09.svg'
import icon_10 from './shape/icon_10.svg'

import icon_11 from './icon/icon_11.svg'

import media9 from './logo/media_09.png'
import media10 from './logo/media_10.png'
import media11 from './logo/media_11.png'
import media12 from './logo/media_12.png'
import media13 from './logo/media_13.png'

import blogimg1 from './blog/blog_img_01.jpg'
import blogimg2 from './blog/blog_img_02.jpg'
import blogimg3 from './blog/blog_img_03.jpg'


export {
    logo,
    logo2,
    logo3,
    lazy,
    img_01,
    img_02,
    img_03,
    img_04,
    img_09,
    screen_01,
    screen_02,
    screen_03,
    shape_1,
    shape_2,
    shape_3,
    shape_7,
    shape_8,
    shape_9,
    shape_10,
    shape_12,
    shape_13,
    shape_14,
    icon_10,
    icon_8,
    icon_9,
    icon_11,
    media10,
    media11,
    media12,
    media13,
    media9,
    blogimg1,
    blogimg2,
    blogimg3
}