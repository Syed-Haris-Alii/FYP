import React from 'react'

const Candidatejobalert = () => {
  return (
    <div className="dashboard-body">
      <div className="position-relative">
        {/* ************************ Header **************************** */}
       
        {/* End Header */}
        <div className="d-flex align-items-center justify-content-between mb-40 lg-mb-30">
          <h2 className="main-title m0">Job Alerts</h2>
          <div className="short-filter d-flex align-items-center">
            <div className="text-dark fw-500 me-2">Short by:</div>
            <select className="nice-select">
              <option value={0}>New</option>
              <option value={1}>Category</option>
              <option value={2}>Job Type</option>
            </select>
          </div>
        </div>
        <div className="bg-white card-box border-20">
          <div className="table-responsive">
            <table className="table job-alert-table">
              <thead>
                <tr>
                  <th scope="col">Title</th>
                  <th scope="col">Alert </th>
                  <th scope="col">Job</th>
                  <th scope="col">Time</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody className="border-0">
                <tr>
                  <td>Product Designer</td>
                  <td>
                    <div className="job-type fw-500">Fulltime</div>
                    <div>Yearly Salary . Germany</div>
                    <div>Design, Product</div>
                  </td>
                  <td>Jobs found 2</td>
                  <td>Weekly</td>
                  <td>
                    <div className="action-dots float-end">
                      <button className="action-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span />
                      </button>
                      <ul className="dropdown-menu dropdown-menu-end">
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_18.svg" alt className="lazy-img" /> View</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_19.svg" alt className="lazy-img" /> Share</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_20.svg" alt className="lazy-img" /> Edit</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_21.svg" alt className="lazy-img" /> Delete</a></li>
                      </ul>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>Marketing</td>
                  <td>
                    <div className="job-type fw-500 part-time">Part-Time</div>
                    <div>Weekly Salary . United kingdom</div>
                    <div>Account, Marketing</div>
                  </td>
                  <td>Jobs found 13</td>
                  <td>Monthly</td>
                  <td>
                    <div className="action-dots float-end">
                      <button className="action-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span />
                      </button>
                      <ul className="dropdown-menu dropdown-menu-end">
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_18.svg" alt className="lazy-img" /> View</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_19.svg" alt className="lazy-img" /> Share</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_20.svg" alt className="lazy-img" /> Edit</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_21.svg" alt className="lazy-img" /> Delete</a></li>
                      </ul>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>Hotel Manager</td>
                  <td>
                    <div className="job-type fw-500">Fulltime</div>
                    <div>Yearly Salary . Germany</div>
                    <div>Design, Product</div>
                  </td>
                  <td>Jobs found 7</td>
                  <td>Daily</td>
                  <td>
                    <div className="action-dots float-end">
                      <button className="action-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span />
                      </button>
                      <ul className="dropdown-menu dropdown-menu-end">
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_18.svg" alt className="lazy-img" /> View</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_19.svg" alt className="lazy-img" /> Share</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_20.svg" alt className="lazy-img" /> Edit</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_21.svg" alt className="lazy-img" /> Delete</a></li>
                      </ul>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>Developer</td>
                  <td>
                    <div className="job-type fw-500">Fulltime</div>
                    <div>Monthly Salary . United States</div>
                    <div>Account, Finance</div>
                  </td>
                  <td>Jobs found 3</td>
                  <td>Weekly</td>
                  <td>
                    <div className="action-dots float-end">
                      <button className="action-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span />
                      </button>
                      <ul className="dropdown-menu dropdown-menu-end">
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_18.svg" alt className="lazy-img" /> View</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_19.svg" alt className="lazy-img" /> Share</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_20.svg" alt className="lazy-img" /> Edit</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_21.svg" alt className="lazy-img" /> Delete</a></li>
                      </ul>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>Account Manager</td>
                  <td>
                    <div className="job-type fw-500 part-time">Part-Time</div>
                    <div>Hourly Salary . Spain</div>
                    <div>Account, Finance</div>
                  </td>
                  <td>Jobs found 9</td>
                  <td>Monthly</td>
                  <td>
                    <div className="action-dots float-end">
                      <button className="action-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span />
                      </button>
                      <ul className="dropdown-menu dropdown-menu-end">
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_18.svg" alt className="lazy-img" /> View</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_19.svg" alt className="lazy-img" /> Share</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_20.svg" alt className="lazy-img" /> Edit</a></li>
                        <li><a className="dropdown-item" href="#"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_21.svg" alt className="lazy-img" /> Delete</a></li>
                      </ul>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
            {/* /.table job-alert-table */}
          </div>
        </div>
        {/* /.card-box */}
        <div className="dash-pagination d-flex justify-content-end mt-30">
          <ul className="style-none d-flex align-items-center">
            <li><a href="#" className="active">1</a></li>
            <li><a href="#">2</a></li>
            <li><a href="#">3</a></li>
            <li>..</li>
            <li><a href="#">7</a></li>
            <li><a href="#"><i className="bi bi-chevron-right" /></a></li>
          </ul>
        </div>
      </div>
    </div>

  )
}

export default Candidatejobalert