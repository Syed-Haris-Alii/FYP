import React from 'react'
import { icon_10, icon_8, icon_9, shape_7, shape_8, shape_9 } from '../assets/images'

const How_it_works = () => {
    return (
        <section className="how-it-works position-relative bg-color pt-110 lg-pt-80 pb-110 lg-pb-70">
            <div className="container">
                <div className="title-one text-center mb-65 lg-mb-40">
                    <h2 className="text-white">How it’s <span className="position-relative">work? <img src={shape_7} alt className="lazy-img shapes shape" style={{}} /></span></h2>
                </div>
                <div className="row justify-content-center">
                    <div className="col-xxl-3 col-lg-4 col-md-6">
                        <div className="card-style-two text-center mt-25 wow fadeInUp" style={{ visibility: 'visible', animationName: 'fadeInUp' }}>
                            <div className="icon rounded-circle d-flex align-items-center justify-content-center m-auto"><img src={icon_8} alt className="lazy-img" style={{}} /></div>
                            <div className="title fw-500 text-white">Create Account</div>
                            <p>It’s very easy to open an account and start your journey.</p>
                        </div>
                    </div>
                    <div className="col-xxl-3 col-lg-4 col-md-6 m-auto">
                        <div className="card-style-two text-center position-relative arrow mt-25 wow fadeInUp" data-wow-delay="0.1s" style={{ visibility: 'visible', animationDelay: '0.1s', animationName: 'fadeInUp' }}>
                            <div className="icon rounded-circle d-flex align-items-center justify-content-center m-auto"><img src={icon_9} alt className="lazy-img" style={{}} /></div>
                            <div className="title fw-500 text-white">Complete your profile</div>
                            <p>Complete your profile with all the info to get attention of client.</p>
                        </div>
                    </div>
                    <div className="col-xxl-3 col-lg-4 col-md-6">
                        <div className="card-style-two text-center mt-25 wow fadeInUp" data-wow-delay="0.19s" style={{ visibility: 'visible', animationDelay: '0.19s', animationName: 'fadeInUp' }}>
                            <div className="icon rounded-circle d-flex align-items-center justify-content-center m-auto"><img src={icon_10} alt className="lazy-img" style={{}} /></div>
                            <div className="title fw-500 text-white">Apply job or hire</div>
                            <p>Apply &amp; get your preferable jobs with all the requirements and get it.</p>
                        </div>
                    </div>
                </div>
            </div>
            <img src={shape_8} alt className="lazy-img shapes shape_01" style={{}} />
            <img src={shape_9} alt className="lazy-img shapes shape_02" style={{}} />
        </section>


    )
}

export default How_it_works