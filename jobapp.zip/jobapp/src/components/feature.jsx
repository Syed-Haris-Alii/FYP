import React from 'react'
import { img_02, img_03, img_04, lazy, screen_01, screen_02, screen_03 } from '../assets/images'

const Feature = () => {
    return (
        <section className="text-feature-one position-relative pt-180 xl-pt-150 lg-pt-100 md-pt-80 pb-180 xl-pb-150">
            <div className="container">
                <div className="row">
                    <div className="col-lg-5 order-lg-last">
                        <div className="ps-xxl-4 wow fadeInRight" style={{ visibility: 'visible', animationName: 'fadeInRight' }}>
                            <div className="title-one">
                                <h2>Get over 50.000+ talented experts in smartemployer.</h2>
                            </div>
                            <p className="mt-40 md-mt-20 mb-40 md-mb-20">A full hybrid workforce management tools are yours to use, as well as access to our top 1% of talent. </p>
                            <ul className="list-style-one style-none">
                                <li>Seamless searching</li>
                                <li>Get top 3% experts for your project</li>
                                <li>Protected payments system</li>
                            </ul>
                            <a href="signup.html" className="btn-one lg mt-50 md-mt-30">Post a Job</a>
                        </div>
                    </div>
                    <div className="col-lg-7 col-md-11 m-auto order-lg-first">
                        <div className="img-data position-relative pe-xl-5 me-xl-5 md-mt-50">
                            <div className="row">
                                <div className="col-md-6 col-sm-8 col-10">
                                    <img src={img_02} alt className="lazy-img img01" style={{}} />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-4 col-5">
                                    <img src={img_03} alt className="lazy-img img02 mt-35" style={{}} />
                                </div>
                                <div className="col-md-6 col-7">
                                    <img src={img_04} alt className="lazy-img img01 mt-35" style={{}} />
                                </div>
                            </div>
                            <img src={screen_01} alt className="lazy-img shapes screen01 wow fadeInRight" style={{ visibility: 'visible', animationName: 'fadeInRight' }} />
                            <img src={screen_02} alt className="lazy-img shapes screen02 wow fadeInUp" style={{ visibility: 'visible', animationName: 'fadeInUp' }} />
                            <img src={screen_03} alt className="lazy-img shapes screen03 wow fadeInUp" style={{ visibility: 'visible', animationName: 'fadeInUp' }} />
                        </div>
                    </div>
                </div>
            </div>
        </section>


    )
}

export default Feature