import React from 'react'

const Candidateprofile = () => {
    return (
        <div className="dashboard-body">
            <div className="position-relative">
                {/* ************************ Header **************************** */}
               
                {/* End Header */}
                <h2 className="main-title">My Profile</h2>
                <div className="bg-white card-box border-20">
                    <div className="user-avatar-setting d-flex align-items-center mb-30">
                        <img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/avatar_02.jpg" alt className="lazy-img user-img" />
                        <div className="upload-btn position-relative tran3s ms-4 me-3">
                            Upload new photo
                            <input type="file" id="uploadImg" name="uploadImg" placeholder />
                        </div>
                        <button className="delete-btn tran3s">Delete</button>
                    </div>
                    {/* /.user-avatar-setting */}
                    <div className="dash-input-wrapper mb-30">
                        <label htmlFor>Full Name*</label>
                        <input type="text" placeholder="Md Rashed Kabir" />
                    </div>
                    {/* /.dash-input-wrapper */}
                    <div className="dash-input-wrapper">
                        <label htmlFor>Bio*</label>
                        <textarea className="size-lg" placeholder="Write something interesting about you...." defaultValue={""} />
                        <div className="alert-text">Brief description for your profile. URLs are hyperlinked.</div>
                    </div>
                    {/* /.dash-input-wrapper */}
                </div>
                {/* /.card-box */}
                <div className="bg-white card-box border-20 mt-40">
                    <h4 className="dash-title-three">Social Media</h4>
                    <div className="dash-input-wrapper mb-20">
                        <label htmlFor>Network 1</label>
                        <input type="text" placeholder="https://www.facebook.com/zubayer0145" />
                    </div>
                    {/* /.dash-input-wrapper */}
                    <div className="dash-input-wrapper mb-20">
                        <label htmlFor>Network 2</label>
                        <input type="text" placeholder="https://twitter.com/FIFAcom" />
                    </div>
                    {/* /.dash-input-wrapper */}
                    <a href="#" className="dash-btn-one"><i className="bi bi-plus" /> Add more link</a>
                </div>
                {/* /.card-box */}
                <div className="bg-white card-box border-20 mt-40">
                    <h4 className="dash-title-three">Address &amp; Location</h4>
                    <div className="row">
                        <div className="col-12">
                            <div className="dash-input-wrapper mb-25">
                                <label htmlFor>Address*</label>
                                <input type="text" placeholder="Cowrasta, Chandana, Gazipur Sadar" />
                            </div>
                            {/* /.dash-input-wrapper */}
                        </div>
                        <div className="col-lg-3">
                            <div className="dash-input-wrapper mb-25">
                                <label htmlFor>Country*</label>
                                <select className="nice-select">
                                    <option>Afghanistan</option>
                                    <option>Albania</option>
                                    <option>Algeria</option>
                                    <option>Andorra</option>
                                    <option>Angola</option>
                                    <option>Antigua and Barbuda</option>
                                    <option>Argentina</option>
                                    <option>Armenia</option>
                                    <option>Australia</option>
                                    <option>Austria</option>
                                    <option>Azerbaijan</option>
                                    <option>Bahamas</option>
                                    <option>Bahrain</option>
                                    <option>Bangladesh</option>
                                    <option>Barbados</option>
                                    <option>Belarus</option>
                                    <option>Belgium</option>
                                    <option>Belize</option>
                                    <option>Benin</option>
                                    <option>Bhutan</option>
                                </select>
                            </div>
                            {/* /.dash-input-wrapper */}
                        </div>
                        <div className="col-lg-3">
                            <div className="dash-input-wrapper mb-25">
                                <label htmlFor>City*</label>
                                <select className="nice-select">
                                    <option>Dhaka</option>
                                    <option>Tokyo</option>
                                    <option>Delhi</option>
                                    <option>Shanghai</option>
                                    <option>Mumbai</option>
                                    <option>Bangalore</option>
                                </select>
                            </div>
                            {/* /.dash-input-wrapper */}
                        </div>
                        <div className="col-lg-3">
                            <div className="dash-input-wrapper mb-25">
                                <label htmlFor>Zip Code*</label>
                                <input type="number" placeholder={1708} />
                            </div>
                            {/* /.dash-input-wrapper */}
                        </div>
                        <div className="col-lg-3">
                            <div className="dash-input-wrapper mb-25">
                                <label htmlFor>State*</label>
                                <select className="nice-select">
                                    <option>Dhaka</option>
                                    <option>Tokyo</option>
                                    <option>Delhi</option>
                                    <option>Shanghai</option>
                                    <option>Mumbai</option>
                                    <option>Bangalore</option>
                                </select>
                            </div>
                            {/* /.dash-input-wrapper */}
                        </div>
                        <div className="col-12">
                            <div className="dash-input-wrapper mb-25">
                                <label htmlFor>Map Location*</label>
                                <div className="position-relative">
                                    <input type="text" placeholder="XC23+6XC, Moiran, N105" />
                                    <button className="location-pin tran3s"><img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/icon/icon_16.svg" alt className="lazy-img m-auto" /></button>
                                </div>
                                <div className="map-frame mt-30">
                                    <div className="gmap_canvas h-100 w-100">
                                        <iframe className="gmap_iframe h-100 w-100" src="https://maps.google.com/maps?width=600&height=400&hl=en&q=dhaka%20collage&t=&z=12&ie=UTF8&iwloc=B&output=embed" />
                                    </div>
                                </div>
                            </div>
                            {/* /.dash-input-wrapper */}
                        </div>
                    </div>
                </div>
                {/* /.card-box */}
                <div className="button-group d-inline-flex align-items-center mt-30">
                    <a href="#" className="dash-btn-two tran3s me-3">Save</a>
                    <a href="#" className="dash-cancel-btn tran3s">Cancel</a>
                </div>
            </div>
        </div>

    )
}

export default Candidateprofile