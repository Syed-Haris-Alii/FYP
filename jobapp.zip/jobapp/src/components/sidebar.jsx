import React from 'react'
import { Link } from 'react-router-dom'

const Sidebar = ({sidebarOpt}) => {

    return (
        <aside className="dash-aside-navbar">
            <div className="position-relative">
                <div className="logo text-md-center d-md-block d-flex align-items-center justify-content-between">
                    <Link to="/dashboard">
                        <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/logo_01.png" alt />
                    </Link>
                    <button className="close-btn d-block d-md-none"><i className="bi bi-x-lg" /></button>
                </div>
                <div className="user-data">
                    <div className="user-avatar online position-relative rounded-circle">
                        <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/avatar_01.jpg" data-src="images/avatar_01.jpg" alt className="lazy-img" />
                    </div>
                    {/* /.user-avatar */}
                    <div className="user-name-data">
                        <button className="user-name" type="button" id="profile-dropdown" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                            Rashed Kabir
                        </button>
                        
                    </div>
                </div>
                {/* /.user-data */}
                <nav className="dasboard-main-nav">
                    <ul className="style-none">
                        <li><Link to="/dashboard" className={`d-flex w-100 align-items-center ${sidebarOpt == 1 ? 'active' : ''}`}>
                            <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/icon/icon_1.svg" data-src="images/icon/icon_1_active.svg" alt className="lazy-img" />
                            <span>Dashboard</span>
                        </Link></li>
                        <li><Link to="/profile" className={`d-flex w-100 align-items-center ${sidebarOpt == 2 ? 'active' : ''}`}>
                            <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/icon/icon_2.svg" data-src="images/icon/icon_2.svg" alt className="lazy-img" />
                            <span>My Profile</span>
                        </Link></li>
                        <li><Link to="/resume" className={`d-flex w-100 align-items-center ${sidebarOpt == 3 ? 'active' : ''}`}>
                            <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/icon/icon_3.svg" data-src="images/icon/icon_3.svg" alt className="lazy-img" />
                            <span>Resume</span>
                        </Link></li>
                        
                        <li><Link to="/job-alert" className={`d-flex w-100 align-items-center ${sidebarOpt == 4 ? 'active' : ''}`}>
                            <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/icon/icon_5.svg" data-src="images/icon/icon_5.svg" alt className="lazy-img" />
                            <span>Job Alert</span>
                        </Link></li>
                        <li><Link to="#" className={`d-flex w-100 align-items-center`} data-bs-toggle="modal" data-bs-target="#deleteModal">
                            <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/icon/icon_8.svg" data-src="images/icon/icon_8.svg" alt className="lazy-img" />
                            <span>Delete Account</span>
                        </Link></li>
                    </ul>
                </nav>
                <Link to="/" className="d-flex w-100 align-items-center logout-btn">
                    <img src="https://html.creativegigstf.com/jobi/jobi/dashboard/images/icon/icon_9.svg" data-src="images/icon/icon_9.svg" alt className="lazy-img" />
                    <span>Logout</span>
                </Link>
            </div>
        </aside>

    )
}

export default Sidebar