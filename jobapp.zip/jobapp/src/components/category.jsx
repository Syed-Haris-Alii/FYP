import React from 'react'
import { lazy } from '../assets/images'

const Category = () => {
    return (
        <section className="category-section-one bg-color position-relative pt-180 xl-pt-150 lg-pt-80 pb-140 xl-pb-120 lg-pb-60">
            <div className="container">
                <div className="row justify-content-between align-items-center">
                    <div className="col-lg-6">
                        <div className="title-one">
                            <h2>Most <span className="position-relative">Demanding <img src={lazy} data-src="images/shape/shape_04.svg" alt className="lazy-img shapes shape" /></span> Categories.</h2>
                        </div>
                    </div>
                    <div className="col-xxl-5 col-lg-6">
                        <p className="text-md mb-25 lg-mb-10 md-mt-20">Together with useful notifications, collaboration, insights, and improvement tip lorem etc.</p>
                        <a href="job-grid-v1.html" className="btn-two d-none d-lg-inline-block">Explore all fields</a>
                    </div>
                </div>
                <div className="card-wrapper row justify-content-center mt-75 lg-mt-40 md-mt-10">
                    <div className="card-style-one text-center mt-20 wow fadeInUp">
                        <a href="job-grid-v1.html" className="bg wrapper active">
                            <div className="icon d-flex align-items-center justify-content-center"><img src={lazy} data-src="images/icon/icon_01.svg" alt className="lazy-img" /></div>
                            <div className="title fw-500">UI/UX Design</div>
                            <div className="total-job">12k+ Jobs</div>
                        </a>
                    </div>
                    <div className="card-style-one text-center mt-20 wow fadeInUp" data-wow-delay="0.1s">
                        <a href="job-grid-v2.html" className="bg wrapper">
                            <div className="icon d-flex align-items-center justify-content-center"><img src={lazy} data-src="images/icon/icon_02.svg" alt className="lazy-img" /></div>
                            <div className="title fw-500">Development</div>
                            <div className="total-job">8k+ Jobs</div>
                        </a>
                    </div>
                    <div className="card-style-one text-center mt-20 wow fadeInUp" data-wow-delay="0.15s">
                        <a href="job-grid-v3.html" className="bg wrapper">
                            <div className="icon d-flex align-items-center justify-content-center"><img src={lazy} data-src="images/icon/icon_03.svg" alt className="lazy-img" /></div>
                            <div className="title fw-500">Marketing</div>
                            <div className="total-job">10k+ Jobs</div>
                        </a>
                    </div>
                    <div className="card-style-one text-center mt-20 wow fadeInUp" data-wow-delay="0.16s">
                        <a href="job-grid-v1.html" className="bg wrapper">
                            <div className="icon d-flex align-items-center justify-content-center"><img src={lazy} data-src="images/icon/icon_04.svg" alt className="lazy-img" /></div>
                            <div className="title fw-500">Telemarketing</div>
                            <div className="total-job">6k+ Jobs</div>
                        </a>
                    </div>
                    <div className="card-style-one text-center mt-20 wow fadeInUp" data-wow-delay="0.17s">
                        <a href="job-grid-v2.html" className="bg wrapper">
                            <div className="icon d-flex align-items-center justify-content-center"><img src={lazy} data-src="images/icon/icon_05.svg" alt className="lazy-img" /></div>
                            <div className="title fw-500">Editing</div>
                            <div className="total-job">7k+ Jobs</div>
                        </a>
                    </div>
                    <div className="card-style-one text-center mt-20 wow fadeInUp" data-wow-delay="0.18s">
                        <a href="job-grid-v3.html" className="bg wrapper">
                            <div className="icon d-flex align-items-center justify-content-center"><img src={lazy} data-src="images/icon/icon_06.svg" alt className="lazy-img" /></div>
                            <div className="title fw-500">Accounting</div>
                            <div className="total-job">17k+ Jobs</div>
                        </a>
                    </div>
                </div>
                <div className="text-center mt-40 d-lg-none">
                    <a href="job-grid-v1.html" className="btn-two">Explore all fields</a>
                </div>
            </div>
            <img src={lazy} data-src="images/shape/shape_05.svg" alt className="lazy-img shapes shape_01" />
        </section>

    )
}

export default Category