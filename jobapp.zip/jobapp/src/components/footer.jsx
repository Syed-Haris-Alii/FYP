import React from 'react'
import { lazy, logo3 } from '../assets/images'
import { Link } from 'react-router-dom'

const Footer = () => {
    return (
        <div className="footer-one">
            <div className="container">
                <div className="inner-wrapper">
                    <div className="row">
                        <div className="col-lg-2 col-md-3 footer-intro mb-15">
                            <div className="logo mb-15">
                                <Link to="/" className="d-flex align-items-center">
                                    <img src={logo3} alt />
                                </Link>
                            </div>
                            <img src={lazy} data-src="images/shape/shape_28.svg" alt className="lazy-img mt-80 sm-mt-30 sm-mb-20" />
                        </div>
                        <div className="col-lg-2 col-md-3 col-sm-4 mb-20">
                            <h5 className="footer-title">Company</h5>
                            <ul className="footer-nav-link style-none">
                                <li><Link to="/about">About us</Link></li>
                                <li><Link to="/blog">Blogs</Link></li>
                                <li><Link to="/faq">FAQ’s</Link></li>
                                <li><Link to="/contact">Contact</Link></li>
                            </ul>
                        </div>
                        <div className="col-lg-2 col-md-3 col-sm-4 mb-20">
                            <h5 className="footer-title">Support</h5>
                            <ul className="footer-nav-link style-none">
                                <li><Link to="/terms-conditions">Terms of use</Link></li>
                                <li><Link to="/terms-conditions">Terms &amp; conditions</Link></li>
                                <li><Link to="/privacy-policy">Privacy</Link></li>
                                <li><Link to="/cookie-policy">Cookie policy</Link></li>
                            </ul>
                        </div>
                        <div className="col-lg-6 mb-20 footer-newsletter">
                            <h5 className="footer-title">Newsletter</h5>
                            <p>Join &amp; get important new regularly</p>
                            <form action="#" className="d-flex">
                                <input type="email" placeholder="Enter your email*" />
                                <button>Send</button>
                            </form>
                            <p className="note">We only send interesting and relevant emails.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="bottom-footer">
                <div className="container">
                    <div className="row align-items-center">
                        <div className="col-lg-4 order-lg-3 mb-15">
                            <ul className="style-none d-flex order-lg-last justify-content-center justify-content-lg-end social-icon">
                                <li><Link to="#"><i className="bi bi-whatsapp" /></Link></li>
                                <li><Link to="#"><i className="bi bi-dribbble" /></Link></li>
                                <li><Link to="#"><i className="bi bi-google" /></Link></li>
                                <li><Link to="#"><i className="bi bi-instagram" /></Link></li>
                            </ul>
                        </div>
                        <div className="col-lg-4 order-lg-1 mb-15">
                            <ul className="d-flex style-none bottom-nav justify-content-center justify-content-lg-start">
                                <li><Link to="/privacy-policy">Privacy &amp; Terms.</Link></li>
                                <li><Link to="/contact"> Contact Us</Link></li>
                            </ul>
                        </div>
                        <div className="col-lg-4 order-lg-2">
                            <p className="text-center mb-15">Copyright @2023 smartemployer inc.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default Footer