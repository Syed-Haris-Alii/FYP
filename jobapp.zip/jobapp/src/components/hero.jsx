import React from 'react'
import { img_01, lazy, shape_1, shape_2, shape_3 } from '../assets/images'

const Hero = () => {
    return (
        <div className="hero-banner-one position-relative">
            <div className="container">
                <div className="position-relative pt-200 md-pt-150 pb-150 xl-pb-120 md-pb-80">
                    <div className="row">
                        <div className="col-lg-6">
                            <h1>Find &amp; Hire <span>Top 3% of expert on smartemployer.</span></h1>
                            <p className="text-lg text-white mt-40 md-mt-30 mb-50 md-mb-30">We delivered blazing fast &amp; striking work solution</p>
                        </div>
                    </div>
                    <div className="position-relative">
                        <div className="row">
                            <div className="col-xl-9 col-lg-8">
                                
                            </div>
                        </div>
                    </div>
                    <div className="img-box">
                        <img src={shape_1} alt className="lazy-img shapes" style={{}} />
                        <img src={img_01} alt className="lazy-img w-100" style={{}} />
                    </div>
                </div>
            </div>
            <img src={shape_2} alt className="lazy-img shapes shape_01" style={{}} />
            <img src={shape_3} alt className="lazy-img shapes shape_02" style={{}} />
        </div>

    )
}

export default Hero