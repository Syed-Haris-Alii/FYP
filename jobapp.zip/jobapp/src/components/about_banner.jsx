import React from 'react'
import { shape_2, shape_3 } from '../assets/images'

const About_banner = ({title}) => {
    return (
        <div className="inner-banner-one position-relative">
            <div className="container">
                <div className="position-relative">
                    <div className="row">
                        <div className="col-xl-6 m-auto text-center">
                            <div className="title-two">
                                <h2 className="text-white">{title}</h2>
                            </div>
                            <ul className="style-none d-flex justify-content-center page-pagination mt-15">
                                <li><a href="index.html">Home</a></li>
                                <li><i className="bi bi-chevron-right" /></li>
                                <li>{title}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <img src={shape_2} alt className="lazy-img shapes shape_01" style={{}} />
            <img src={shape_3} alt className="lazy-img shapes shape_02" style={{}} />
        </div>

    )
}

export default About_banner