import React from 'react'
import { logo2, media10, media11, media12, media13, media9, shape_10 } from '../assets/images'

const Feature_2 = () => {
    return (
        <section className="text-feature-two position-relative pt-180 xl-pt-150 lg-pt-100 pb-180 xl-pb-150 lg-pb-120">
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-lg-5 order-lg-last">
                        <div className="wow fadeInRight" style={{ visibility: 'visible', animationName: 'fadeInRight' }}>
                            <div className="title-one">
                                <div className="sub-title">TOP BRAND</div>
                                <h2>Collaboration with Top Brands.</h2>
                            </div>
                            <p className="text-lg mt-40 lg-mt-20 mb-40 lg-mb-30">We collaborate with a number of top tier companies on imagining the future of work, have a look.</p>
                            <a href="about-us.html" className="btn-nine tran3s d-flex align-items-center">
                                <span className="fw-500 me-2">Learn More</span>
                                <i className="bi bi-arrow-right" />
                            </a>
                        </div>
                    </div>
                    <div className="col-lg-7 order-lg-first">
                        <div className="big-circle rounded-circle position-relative d-flex align-items-center justify-content-center ms-lg-5 wow fadeInLeft" style={{ visibility: 'visible', animationName: 'fadeInLeft' }}>
                            <div className="inner-circle rounded-circle d-flex align-items-center justify-content-center">
                                <img src={logo2} alt className="lazy-img" style={{}} />
                            </div>
                            <div className="brand-icon icon_01 rounded-circle d-flex align-items-center justify-content-center">
                                <img src={media9} alt className="lazy-img" style={{}} />
                            </div>
                            <div className="brand-icon icon_02 rounded-circle d-flex align-items-center justify-content-center">
                                <img src={media10} alt className="lazy-img" style={{}} />
                            </div>
                            <div className="brand-icon icon_03 rounded-circle d-flex align-items-center justify-content-center">
                                <img src={media11} alt className="lazy-img" style={{}} />
                            </div>
                            <div className="brand-icon icon_04 rounded-circle d-flex align-items-center justify-content-center">
                                <img src={media12} alt className="lazy-img" style={{}} />
                            </div>
                            <div className="brand-icon icon_05 rounded-circle d-flex align-items-center justify-content-center">
                                <img src={media13} alt className="lazy-img" style={{}} />
                            </div>
                            <img src={shape_10} alt className="lazy-img shapes shape_01" style={{}} />
                        </div>
                    </div>
                </div>
            </div>
        </section>


    )
}

export default Feature_2