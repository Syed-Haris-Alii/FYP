import React, { useState } from 'react'
import {Link} from 'react-router-dom'
import '../assets/css/bootstrap.min.css'
import '../assets/css/style.min.css'
import '../assets/css/responsive.css'

import { logo } from '../assets/images'
import { lazy } from '../assets/images'

const Navbar = () => {
    const[mobile, setMobile] = useState(false)
    return (
        <header className="theme-main-menu menu-overlay menu-style-one sticky-menu">
            <div className="inner-content position-relative">
                <div className="top-header">
                    <div className="d-flex align-items-center">
                        <div className="logo order-lg-0">
                            <Link to="/" className="d-flex align-items-center">
                                <img src={logo} alt />
                            </Link>
                        </div>
                        <div className="right-widget ms-auto order-lg-3">
                            <ul className="d-flex align-items-center style-none">
                                <li className="d-none d-md-block"><Link to="/jobs" className="job-post-btn tran3s">Find Job</Link></li>
                                <li><Link to="/login" className="login-btn-one">Login</Link></li>
                                
                            </ul>
                        </div>
                        <nav className="navbar navbar-expand-lg p0 ms-lg-5 ms-3 order-lg-2">


                            <button onClick={() => setMobile(!mobile)} className="navbar-toggler d-block d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                                <span />
                            </button>



                            <div className={`collapse navbar-collapse ${mobile == true ? 'show' : ''}`} id="navbarNav">
                                <ul className="navbar-nav align-items-lg-center">
                                    <li className="d-block d-lg-none"><div className="logo"><Link to="index.html" className="d-block"><img src={logo} alt width={100} /></Link></div></li>
                                    
                                    
                                    <li className="nav-item dropdown">
                                        <Link to={'/'} className="nav-link " role="button"  data-bs-auto-close="outside" aria-expanded="false">Home
                                        </Link>
                                    </li>
                                    <li className="nav-item dropdown">
                                        <Link to={'/about'} className="nav-link " role="button"  data-bs-auto-close="outside" aria-expanded="false">About Us
                                        </Link>
                                    </li>
                                    <li className="nav-item dropdown mega-dropdown-sm">
                                        <Link to={'/faq'} className="nav-link " role="button"  data-bs-auto-close="outside" aria-expanded="false">FAQ'S
                                        </Link>
                                    </li>
                                    <li className="nav-item dropdown">
                                        <Link to={'/blog'} className="nav-link " role="button"  data-bs-auto-close="outside" aria-expanded="false">Blog
                                        </Link>
                                        
                                    </li>
                                    <li className="nav-item dropdown">
                                        <Link to={'/pricing'} className="nav-link " role="button"  data-bs-auto-close="outside" aria-expanded="false">Pricing
                                        </Link>
                                        
                                    </li>
                                    <li className="nav-item">
                                        <Link to={'/contact'} className="nav-link" role="button">Contact</Link>
                                    </li>
                                </ul>
                            </div>



                        </nav>
                    </div>
                </div>
            </div>
        </header>

    )
}

export default Navbar