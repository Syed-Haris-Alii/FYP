import React from 'react'

const Feature_3 = () => {
    return (
        <section className="text-feature-three position-relative pt-100 lg-pt-80 md-pt-50">
            <div className="container">
                <div className="row">
                    <div className="col-xxl-11 m-auto">
                        <div className="row">
                            <div className="col-lg-5">
                                <div className="title-one mt-30 md-mb-40">
                                    <h2 className="fw-500">We’ve been helping customer globally.</h2>
                                </div>
                            </div>
                            <div className="col-lg-6 ms-auto">
                                <div className="wow fadeInRight" style={{ visibility: 'visible', animationName: 'fadeInRight' }}>
                                    <div className="accordion accordion-style-one color-two ps-xxl-5 ms-xxl-4" id="accordionOne">
                                        <div className="accordion-item">
                                            <div className="accordion-header" id="headingOne">
                                                <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                    Who we are?
                                                </button>
                                            </div>
                                            <div id="collapseOne" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionOne">
                                                <div className="accordion-body">
                                                    <p>Our founders Dustin Moskovitz and Justin lorem Rosenstein met while leading Engineering teams at Facebook quesi. Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="accordion-item">
                                            <div className="accordion-header" id="headingTwo">
                                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                    What’s our goal
                                                </button>
                                            </div>
                                            <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionOne">
                                                <div className="accordion-body">
                                                    <p>Our founders Dustin Moskovitz and Justin lorem Rosenstein met while leading Engineering teams at Facebook quesi. Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="accordion-item">
                                            <div className="accordion-header" id="headingThree">
                                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                    Our vision
                                                </button>
                                            </div>
                                            <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionOne">
                                                <div className="accordion-body">
                                                    <p>Our founders Dustin Moskovitz and Justin lorem Rosenstein met while leading Engineering teams at Facebook quesi. Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="video-post d-flex align-items-center justify-content-center mt-100 lg-mt-50 mb-50 lg-mb-30">
                            <a className="fancybox rounded-circle video-icon tran3s text-center" data-fancybox href="https://www.youtube.com/embed/aXFSJTjVjw0">
                                <i className="bi bi-play" />
                            </a>
                        </div>
                        <div className="border-bottom pb-50 lg-pb-10">
                            <div className="row">
                                <div className="col-sm-4">
                                    <div className="counter-block-one mt-25 text-center wow fadeInUp" style={{ visibility: 'visible', animationName: 'fadeInUp' }}>
                                        <h2 className="main-count fw-500"><span className="counter">7</span>million</h2>
                                        <p>Completed Jobs</p>
                                    </div>
                                </div>
                                <div className="col-sm-4">
                                    <div className="counter-block-one mt-25 text-center wow fadeInUp" data-wow-delay="0.2s" style={{ visibility: 'visible', animationDelay: '0.2s', animationName: 'fadeInUp' }}>
                                        <h2 className="main-count fw-500"><span className="counter">30</span>k+</h2>
                                        <p>Worldwide Client</p>
                                    </div>
                                </div>
                                <div className="col-sm-4">
                                    <div className="counter-block-one mt-25 text-center wow fadeInUp" data-wow-delay="0.35s" style={{ visibility: 'visible', animationDelay: '0.35s', animationName: 'fadeInUp' }}>
                                        <h2 className="main-count fw-500"><span className="counter">13</span>billion</h2>
                                        <p>Dollar Payout</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    )
}

export default Feature_3