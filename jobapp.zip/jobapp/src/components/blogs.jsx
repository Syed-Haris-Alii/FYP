import React from 'react'
import { blogimg1, blogimg2, blogimg3 } from '../assets/images'

const Blogs = () => {
    return (
        <section className="blog-section-one mt-20">
            <div className="container">
                <div className="position-relative">
                    <div className="title-one mb-30 lg-mb-10">
                        <h2>Smartemployer Guides</h2>
                    </div>
                    <div className="row gx-xxl-5">
                        <div className="col-lg-4 col-md-6">
                            <article className="blog-meta-one mt-35 wow fadeInUp" style={{ visibility: 'visible', animationName: 'fadeInUp' }}>
                                <figure className="post-img m0">
                                    <a href="blog-details.html" className="w-100 d-block"><img src={blogimg1} alt className="lazy-img w-100 tran4s" style={{}} /></a>
                                </figure>
                                <div className="post-data mt-30 lg-mt-20">
                                    <ul className="tags style-none d-flex">
                                        <li><a href="#">Developer</a></li>
                                        <li><a href="#">Code</a></li>
                                    </ul>
                                    <a href="blog-details.html" className="mt-10 mb-10"><h4 className="tran3s blog-title">Print, publishing qui visual layout mockups.</h4></a>
                                    <div className="author">By <a href="#" className="text-dark fw-500">Rashed Kabir</a></div>
                                </div>
                            </article>
                        </div>
                        <div className="col-lg-4 col-md-6">
                            <article className="blog-meta-one mt-35 wow fadeInUp" data-wow-delay="0.1s" style={{ visibility: 'visible', animationDelay: '0.1s', animationName: 'fadeInUp' }}>
                                <figure className="post-img m0">
                                    <a href="blog-details.html" className="w-100 d-block"><img src={blogimg2} alt className="lazy-img w-100 tran4s" style={{}} /></a>
                                </figure>
                                <div className="post-data mt-30 lg-mt-20">
                                    <ul className="tags style-none d-flex">
                                        <li><a href="#">Design</a></li>
                                        <li><a href="#">Art</a></li>
                                    </ul>
                                    <a href="blog-details.html" className="mt-10 mb-10"><h4 className="tran3s blog-title">Designer’s checklist for every UX/UI project.</h4></a>
                                    <div className="author">By <a href="#" className="text-dark fw-500">Julie Margot</a></div>
                                </div>
                            </article>
                        </div>
                        <div className="col-lg-4 col-md-6 d-none d-lg-block">
                            <article className="blog-meta-one mt-35 wow fadeInUp" data-wow-delay="0.19s" style={{ visibility: 'visible', animationDelay: '0.19s', animationName: 'fadeInUp' }}>
                                <figure className="post-img m0">
                                    <a href="blog-details.html" className="w-100 d-block"><img src={blogimg3} alt className="lazy-img w-100 tran4s" style={{}} /></a>
                                </figure>
                                <div className="post-data mt-30 lg-mt-20">
                                    <ul className="tags style-none d-flex">
                                        <li><a href="#">Solution</a></li>
                                        <li><a href="#">Work</a></li>
                                    </ul>
                                    <a href="blog-details.html" className="mt-10 mb-10"><h4 className="tran3s blog-title">Make more productive work flow in few steps.</h4></a>
                                    <div className="author">By <a href="#" className="text-dark fw-500">Jubayer Al Hasan</a></div>
                                </div>
                            </article>
                        </div>
                    </div>
                    <div className="text-center explore-btn sm-mt-30"><a href="blog-v1.html" className="btn-one">Explore More</a></div>
                </div>
            </div>
        </section>


    )
}

export default Blogs