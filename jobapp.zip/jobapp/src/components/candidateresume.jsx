import React from 'react'

const Candidateresume = () => {
    return (
        <div className="dashboard-body">
            <div className="position-relative">
                {/* ************************ Header **************************** */}
                
                {/* End Header */}
                <h2 className="main-title">My Resume</h2>
                <div className="bg-white card-box border-20">
                    <h4 className="dash-title-three">Resume Attachment</h4>
                    <div className="dash-input-wrapper mb-20">
                        <label htmlFor>CV Attachment*</label>
                        <div className="attached-file d-flex align-items-center justify-content-between mb-15">
                            <span>MyCvResume.PDF</span>
                            <a href="#" className="remove-btn"><i className="bi bi-x" /></a>
                        </div>
                        <div className="attached-file d-flex align-items-center justify-content-between">
                            <span>CandidateCV02.PDF</span>
                            <a href="#" className="remove-btn"><i className="bi bi-x" /></a>
                        </div>
                    </div>
                    {/* /.dash-input-wrapper */}
                    <div className="dash-btn-one d-inline-block position-relative me-3">
                        <i className="bi bi-plus" />
                        Upload CV
                        <input type="file" id="uploadCV" name="uploadCV" placeholder />
                    </div>
                    <small>Upload file .pdf, .doc, .docx</small>
                </div>
                {/* /.card-box */}
                <div className="bg-white card-box border-20 mt-40">
                    <h4 className="dash-title-three">Intro &amp; Overview</h4>
                    <div className="dash-input-wrapper mb-35 md-mb-20">
                        <label htmlFor>Overview*</label>
                        <textarea className="size-lg" placeholder="Write something interesting about you...." defaultValue={""} />
                        <div className="alert-text">Brief description for your resume. URLs are hyperlinked.</div>
                    </div>
                    {/* /.dash-input-wrapper */}
                    <div className="row">
                        <div className="col-sm-6 d-flex">
                            <div className="intro-video-post position-relative mt-20" style={{ backgroundImage: 'url(images/video_post.jpg)' }}>
                                <a className="fancybox rounded-circle video-icon tran3s text-center" data-fancybox href="https://www.youtube.com/embed/aXFSJTjVjw0">
                                    <i className="bi bi-play" />
                                </a>
                                <a href="#" className="close"><i className="bi bi-x" /></a>
                            </div>
                            {/* /.intro-video-post */}
                        </div>
                        <div className="col-sm-6 d-flex">
                            <div className="intro-video-post position-relative empty mt-20">
                                <span>+ Add Intro Video</span>
                                <input type="file" id="uploadVdo" name="uploadVdo" placeholder />
                            </div>
                            {/* /.intro-video-post */}
                        </div>
                    </div>
                </div>
                {/* /.card-box */}
                <div className="bg-white card-box border-20 mt-40">
                    <h4 className="dash-title-three">Education</h4>
                    <div className="accordion dash-accordion-one" id="accordionOne">
                        <div className="accordion-item">
                            <div className="accordion-header" id="headingOne">
                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                    Add Education*
                                </button>
                            </div>
                            <div id="collapseOne" className="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionOne">
                                <div className="accordion-body">
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Title*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Product Designer (Google)" />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Academy*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Google Arts Collage & University" />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Year*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Description*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <textarea className="size-lg" placeholder="Morbi ornare ipsum sed sem condimentum, et pulvinar tortor luctus. Suspendisse condimentum lorem ut elementum aliquam et pulvinar tortor luctus." defaultValue={""} />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="accordion-item">
                            <div className="accordion-header" id="headingTwo">
                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Add Education*
                                </button>
                            </div>
                            <div id="collapseTwo" className="accordion-collapse collapse show" aria-labelledby="headingTwo" data-bs-parent="#accordionOne">
                                <div className="accordion-body">
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Title*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Product Designer (Google)" />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Academy*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Google Arts Collage & University" />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Year*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Description*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <textarea className="size-lg" placeholder="Morbi ornare ipsum sed sem condimentum, et pulvinar tortor luctus. Suspendisse condimentum lorem ut elementum aliquam et pulvinar tortor luctus." defaultValue={""} />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> {/* /.dash-accordion-one */}
                    <a href="#" className="dash-btn-one"><i className="bi bi-plus" /> Add more</a>
                </div>
                {/* /.card-box */}
                <div className="bg-white card-box border-20 mt-40">
                    <h4 className="dash-title-three">Skills &amp; Experience</h4>
                    <div className="dash-input-wrapper mb-40">
                        <label htmlFor>Add Skills*</label>
                        <div className="skills-wrapper">
                            <ul className="style-none d-flex flex-wrap align-items-center">
                                <li className="is_tag"><button>Figma <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>HTML5 <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>Illustrator <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>Adobe Photoshop <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>WordPress <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>jQuery <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>Web Design <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>Adobe XD <i className="bi bi-x" /></button></li>
                                <li className="is_tag"><button>CSS <i className="bi bi-x" /></button></li>
                                <li className="more_tag"><button>+</button></li>
                            </ul>
                        </div>
                        {/* /.skills-wrapper */}
                    </div>
                    {/* /.dash-input-wrapper */}
                    <div className="dash-input-wrapper mb-15">
                        <label htmlFor>Add Work Experience*</label>
                    </div>
                    {/* /.dash-input-wrapper */}
                    <div className="accordion dash-accordion-one" id="accordionTwo">
                        <div className="accordion-item">
                            <div className="accordion-header" id="headingOneA">
                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOneA" aria-expanded="false" aria-controls="collapseOneA">
                                    Experience 1*
                                </button>
                            </div>
                            <div id="collapseOneA" className="accordion-collapse collapse" aria-labelledby="headingOneA" data-bs-parent="#accordionTwo">
                                <div className="accordion-body">
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Title*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Lead Product Designer " />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Company*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Amazon Inc" />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Year*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Description*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <textarea className="size-lg" placeholder="Morbi ornare ipsum sed sem condimentum, et pulvinar tortor luctus. Suspendisse condimentum lorem ut elementum aliquam et pulvinar tortor luctus." defaultValue={""} />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="accordion-item">
                            <div className="accordion-header" id="headingTwoA">
                                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwoA" aria-expanded="false" aria-controls="collapseTwoA">
                                    Experience 2*
                                </button>
                            </div>
                            <div id="collapseTwoA" className="accordion-collapse collapse show" aria-labelledby="headingTwoA" data-bs-parent="#accordionTwo">
                                <div className="accordion-body">
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Title*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Lead Product Designer " />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Company*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <input type="text" placeholder="Amazon Inc" />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Year*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="row">
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                                <div className="col-sm-6">
                                                    <div className="dash-input-wrapper mb-30">
                                                        <select className="nice-select">
                                                            <option>2023</option>
                                                            <option>2022</option>
                                                            <option>2021</option>
                                                            <option>2020</option>
                                                            <option>2019</option>
                                                            <option>2018</option>
                                                        </select>
                                                    </div>
                                                    {/* /.dash-input-wrapper */}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-2">
                                            <div className="dash-input-wrapper mb-30 md-mb-10">
                                                <label htmlFor>Description*</label>
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                        <div className="col-lg-10">
                                            <div className="dash-input-wrapper mb-30">
                                                <textarea className="size-lg" placeholder="Morbi ornare ipsum sed sem condimentum, et pulvinar tortor luctus. Suspendisse condimentum lorem ut elementum aliquam et pulvinar tortor luctus." defaultValue={""} />
                                            </div>
                                            {/* /.dash-input-wrapper */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> {/* /.dash-accordion-one */}
                    <a href="#" className="dash-btn-one"><i className="bi bi-plus" /> Add more</a>
                </div>
                {/* /.card-box */}
                <div className="bg-white card-box border-20 mt-40">
                    <h4 className="dash-title-three">Portfolio</h4>
                    <div className="row">
                        <div className="col-lg-3 col-6">
                            <div className="candidate-portfolio-block position-relative mb-25">
                                <a href="#" className="d-block">
                                    <img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/portfolio_img_01.jpg" alt className="lazy-img w-100" />
                                </a>
                                <a href="#" className="remove-portfolio-item rounded-circle d-flex align-items-center justify-content-center tran3s"><i className="bi bi-x" /></a>
                            </div>
                            {/* /.candidate-portfolio-block */}
                        </div>
                        <div className="col-lg-3 col-6">
                            <div className="candidate-portfolio-block position-relative mb-25">
                                <a href="#" className="d-block">
                                    <img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/portfolio_img_02.jpg" alt className="lazy-img w-100" />
                                </a>
                                <a href="#" className="remove-portfolio-item rounded-circle d-flex align-items-center justify-content-center tran3s"><i className="bi bi-x" /></a>
                            </div>
                            {/* /.candidate-portfolio-block */}
                        </div>
                        <div className="col-lg-3 col-6">
                            <div className="candidate-portfolio-block position-relative mb-25">
                                <a href="#" className="d-block">
                                    <img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/portfolio_img_03.jpg" alt className="lazy-img w-100" />
                                </a>
                                <a href="#" className="remove-portfolio-item rounded-circle d-flex align-items-center justify-content-center tran3s"><i className="bi bi-x" /></a>
                            </div>
                            {/* /.candidate-portfolio-block */}
                        </div>
                        <div className="col-lg-3 col-6">
                            <div className="candidate-portfolio-block position-relative mb-25">
                                <a href="#" className="d-block">
                                    <img src="https://html.creativegigstf.com/jobi/jobi/images/lazy.svg" data-src="images/portfolio_img_04.jpg" alt className="lazy-img w-100" />
                                </a>
                                <a href="#" className="remove-portfolio-item rounded-circle d-flex align-items-center justify-content-center tran3s"><i className="bi bi-x" /></a>
                            </div>
                            {/* /.candidate-portfolio-block */}
                        </div>
                    </div>
                    <a href="#" className="dash-btn-one"><i className="bi bi-plus" /> Add more</a>
                </div>
                {/* /.card-box */}
                <div className="button-group d-inline-flex align-items-center mt-30">
                    <a href="#" className="dash-btn-two tran3s me-3">Save</a>
                    <a href="#" className="dash-cancel-btn tran3s">Cancel</a>
                </div>
            </div>
        </div>

    )
}

export default Candidateresume