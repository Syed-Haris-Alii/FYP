import React from 'react'
import { icon_11, img_09, shape_12, shape_13, shape_14 } from '../assets/images'

const Fancy_Banner = () => {
    return (
        <section className="fancy-banner-one mt-150 xl-mt-120 lg-mt-100">
            <div className="container">
                <div className="bg-wrapper position-relative ps-4 pe-4 pt-55 wow fadeInUp" style={{ visibility: 'visible', animationName: 'fadeInUp' }}>
                    <div className="row">
                        <div className="col-xxl-11 m-auto">
                            <div className="row">
                                <div className="col-xl-5 col-lg-6 order-lg-last">
                                    <div className="text-wrapper">
                                        <div className="title-two">
                                            <h2 className="text-white">Get your <br /> <span>Matched Jobs</span> in a few minutes.</h2>
                                        </div>
                                        <p className="text-md mt-25 lg-mt-20 mb-45 lg-mb-30">Find your dream job &amp; earn from world leading brands. Upload your CV now.</p>
                                        <form action="#" className="upload-btn position-relative d-flex align-items-center justify-content-center">
                                            <img src={icon_11} alt className="lazy-img" style={{}} /> <span className="fw-500 ms-2 text-dark">Upload your CV</span>
                                            <input type="file" id="uploadCV" name="uploadCV" />
                                        </form>
                                    </div>
                                </div>
                                <div className="col-xl-7 col-lg-6 order-lg-first">
                                    <div className="img-meta md-mt-20 position-relative">
                                        <img src={img_09} alt className="lazy-img m-auto" style={{}} />
                                        <img src={shape_12} alt className="lazy-img shapes shape_01" style={{}} />
                                        <img src={shape_13} alt className="lazy-img shapes shape_02" style={{}} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <img src={shape_14} alt className="lazy-img shapes shape_03" style={{}} />
                </div>
            </div>
        </section>


    )
}

export default Fancy_Banner