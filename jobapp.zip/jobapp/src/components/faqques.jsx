import React, { useState } from 'react'
import {Link} from 'react-router-dom'

const Faqques = () => {
    const [open, setOpen] = useState(null)
    return (
        <>
            <section className="faq-section position-relative pt-40 lg-pt-80">
                <div className="container">
                    <div className="bg-wrapper mt-60 lg-mt-40">
                        <div className="tab-content" id="myTabContent">
                            <div className={`tab-pane fade show active`} role="tabpanel" id="fc1">
                                <div className="accordion accordion-style-two" id="accordionTwo">


                                    <div className="accordion-item">
                                        <div className="accordion-header" id="FheadingOne">
                                            <button onClick={()=>setOpen(0)} className={`accordion-button ${open == 0 ? '' : 'collapsed'} `} type="button" data-bs-toggle="collapse" data-bs-target="#FcollapseOne" aria-expanded="false" aria-controls="FcollapseOne">
                                                How does the free trial work?
                                            </button>
                                        </div>
                                        <div id="FcollapseOne" className={`accordion-collapse ${open == 0 ? '' : 'collapse'} `} aria-labelledby="FheadingOne" data-bs-parent="#accordionTwo">
                                            <div className="accordion-body">
                                                <p>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                                            </div>
                                        </div>
                                    </div>


                                    
                                    <div className="accordion-item">
                                        <div className="accordion-header" id="FheadingTwo">
                                            <button onClick={()=>setOpen(1)} className={`accordion-button ${open == 1 ? '' : 'collapsed'} `} type="button" data-bs-toggle="collapse" data-bs-target="#FcollapseTwo" aria-expanded="false" aria-controls="FcollapseTwo">
                                                How do you find different criteria in your process?
                                            </button>
                                        </div>
                                        <div id="FcollapseTwo" className={`accordion-collapse ${open == 1 ? '' : 'collapse'} `} aria-labelledby="FheadingTwo" data-bs-parent="#accordionTwo">
                                            <div className="accordion-body">
                                                <p>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                                            </div>
                                        </div>
                                    </div>



                                    <div className="accordion-item">
                                        <div className="accordion-header" id="FheadingThree">
                                            <button onClick={()=>setOpen(2)} className={`accordion-button ${open == 2 ? '' : 'collapsed'} `} type="button" data-bs-toggle="collapse" data-bs-target="#FcollapseThree" aria-expanded="false" aria-controls="FcollapseThree">
                                                What do you look for in a founding team?
                                            </button>
                                        </div>
                                        <div id="FcollapseThree" className={`accordion-collapse ${open == 2 ? '' : 'collapse'} `} aria-labelledby="FheadingThree" data-bs-parent="#accordionTwo">
                                            <div className="accordion-body">
                                                <p>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                                            </div>
                                        </div>
                                    </div>


                                    <div className="accordion-item">
                                        <div className="accordion-header" id="FheadingFour">
                                            <button onClick={()=>setOpen(3)} className={`accordion-button ${open == 3 ? '' : 'collapsed'} `} type="button" data-bs-toggle="collapse" data-bs-target="#FcollapseFour" aria-expanded="false" aria-controls="FcollapseFour">
                                                Do you recommend Pay as you go or Pre pay?
                                            </button>
                                        </div>
                                        <div id="FcollapseFour" className={`accordion-collapse ${open == 3 ? '' : 'collapse'} `} aria-labelledby="FheadingFour" data-bs-parent="#accordionTwo">
                                            <div className="accordion-body">
                                                <p>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                                            </div>
                                        </div>
                                    </div>


                                    <div className="accordion-item">
                                        <div className="accordion-header" id="FheadingFive">
                                            <button onClick={()=>setOpen(4)} className={`accordion-button ${open == 4 ? '' : 'collapsed'} `} type="button" data-bs-toggle="collapse" data-bs-target="#FcollapseFive" aria-expanded="false" aria-controls="FcollapseFive">
                                                What do I get for $0 with my plan?
                                            </button>
                                        </div>
                                        <div id="FcollapseFive" className={`accordion-collapse ${open == 4 ? '' : 'collapse'} `} aria-labelledby="FheadingFive" data-bs-parent="#accordionTwo">
                                            <div className="accordion-body">
                                                <p>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                                            </div>
                                        </div>
                                    </div>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="text-center border-bottom pb-150 lg-pb-50 mt-60 lg-mt-40 wow fadeInUp">
                    <div className="title-three mb-30">
                        <h2 className="fw-normal">Don’t get your answer?</h2>
                    </div>
                    <Link to={'/contact'} className="btn-one">Contact Us</Link>
                </div>
            </section>

        </>
    )
}

export default Faqques