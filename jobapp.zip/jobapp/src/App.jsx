import About from "./pages/about"
import Blog from "./pages/blog"
import Contact from "./pages/contact"
import Faq from "./pages/faq"
import Home from "./pages/home"
import { Routes, Route } from 'react-router-dom'
import Terms from "./pages/terms"
import Privacy from "./pages/privacy"
import Cookie from "./pages/cookie"
import Pricing from "./pages/pricing"
import Login from "./pages/login"
import Signup from "./pages/register"
import Jobs from "./pages/jobs"
import Dashboard from "./pages/dashboard"
import Profile from "./pages/profile"
import Resume from "./pages/resume"
import Jobalert from "./pages/jobalert"

const App = () => {
    return (
        <Routes>
            <Route path="" element={<Home />} />
            <Route path="about" element={<About />} />
            <Route path="blog" element={<Blog />} />
            <Route path="faq" element={<Faq />} />
            <Route path="pricing" element={<Pricing />} />
            <Route path="contact" element={<Contact />} />
            <Route path="terms-conditions" element={<Terms />} />
            <Route path="privacy-policy" element={<Privacy />} />
            <Route path="cookie-policy" element={<Cookie />} />
            <Route path="login" element={<Login />} />
            <Route path="signup" element={<Signup />} />
            <Route path="jobs" element={<Jobs />} />


            <Route path="dashboard" element={<Dashboard />} />
            <Route path="profile" element={<Profile />} />
            <Route path="resume" element={<Resume />} />
            <Route path="job-alert" element={<Jobalert />} />
        </Routes>
    )
}

export default App