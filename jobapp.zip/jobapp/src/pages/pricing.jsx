import React from 'react'
import Navbar from '../components/navbar'
import Footer from '../components/footer'
import About_banner from '../components/about_banner'

const Pricing = () => {
    return (
        <>
            <Navbar />
            <About_banner title="Pricing" />

            <section className="pricing-section pt-100 lg-pt-80 pb-120 lg-pb-80">
                <div className="container">
                    <div className="title-one text-center mb-55 lg-mb-20">
                        <h2 className="text-dark fw-normal">Simple Plan for All</h2>
                    </div>
                    <div className="row">
                        <div className="col-xxl-10 m-auto">
                            <div className="row justify-content-center">
                                <div className="col-lg-4 col-md-6">
                                    <div className="pricing-card-one mt-25">
                                        <div className="pack-name">Standard</div>
                                        <div className="price fw-500">0</div>
                                        <ul className="style-none">
                                            <li>15 job posting </li>
                                            <li>7 featured job </li>
                                            <li>Job post live for 30 days </li>
                                        </ul>
                                        <a href="#" className="get-plan-btn tran3s w-100 mt-30">Choose Plan</a>
                                    </div>
                                    {/* /.pricing-card-one */}
                                </div>
                                <div className="col-lg-4 col-md-6">
                                    <div className="pricing-card-one popular mt-25">
                                        <div className="popular-badge">popular</div>
                                        <div className="pack-name">Gold</div>
                                        <div className="price fw-500"><sub>$</sub> 27.<sup>99</sup></div>
                                        <ul className="style-none">
                                            <li>30 job posting </li>
                                            <li>15 featured job </li>
                                            <li>Job post live for 60 days </li>
                                        </ul>
                                        <a href="#" className="get-plan-btn tran3s w-100 mt-30">Choose Plan</a>
                                    </div>
                                    {/* /.pricing-card-one */}
                                </div>
                                <div className="col-lg-4 col-md-6">
                                    <div className="pricing-card-one mt-25">
                                        <div className="pack-name">Diamond</div>
                                        <div className="price fw-500"><sub>$</sub> 39.<sup>99</sup></div>
                                        <ul className="style-none">
                                            <li>60 job posting </li>
                                            <li>30 featured job </li>
                                            <li>Job post live for 130 days </li>
                                        </ul>
                                        <a href="#" className="get-plan-btn tran3s w-100 mt-30">Choose Plan</a>
                                    </div>
                                    {/* /.pricing-card-one */}
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-xl-5 col-lg-8 m-auto">
                                    <p className="text-center mt-60 lg-mt-30">We've done it carefully and simply. Combined with the ingredients makes for beautiful landings.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section className="pricing-section bg-color pt-100 lg-pt-70 pb-90 lg-pb-60">
                <div className="container">
                    <div className="title-one text-center mb-55 lg-mb-20">
                        <h2 className="text-dark fw-normal">Simple Plan for All</h2>
                    </div>
                    <div className="row">
                        <div className="col-xxl-10 m-auto">
                            <div className="row justify-content-center">
                                <div className="col-lg-4 col-md-6">
                                    <div className="pricing-card-one border-0 mt-25">
                                        <div className="pack-name">Standard</div>
                                        <div className="price fw-500">0</div>
                                        <ul className="style-none">
                                            <li>15 job posting </li>
                                            <li>7 featured job </li>
                                            <li>Job post live for 30 days </li>
                                        </ul>
                                        <a href="#" className="get-plan-btn tran3s w-100 mt-30">Choose Plan</a>
                                    </div>
                                    {/* /.pricing-card-one */}
                                </div>
                                <div className="col-lg-4 col-md-6">
                                    <div className="pricing-card-one popular-two mt-25">
                                        <div className="popular-badge">popular</div>
                                        <div className="pack-name">Gold</div>
                                        <div className="price fw-500"><sub>$</sub> 27.<sup>99</sup></div>
                                        <ul className="style-none">
                                            <li>30 job posting </li>
                                            <li>15 featured job </li>
                                            <li>Job post live for 60 days </li>
                                        </ul>
                                        <a href="#" className="get-plan-btn tran3s w-100 mt-30">Choose Plan</a>
                                    </div>
                                    {/* /.pricing-card-one */}
                                </div>
                                <div className="col-lg-4 col-md-6">
                                    <div className="pricing-card-one border-0 mt-25">
                                        <div className="pack-name">Diamond</div>
                                        <div className="price fw-500"><sub>$</sub> 39.<sup>99</sup></div>
                                        <ul className="style-none">
                                            <li>60 job posting </li>
                                            <li>30 featured job </li>
                                            <li>Job post live for 130 days </li>
                                        </ul>
                                        <a href="#" className="get-plan-btn tran3s w-100 mt-30">Choose Plan</a>
                                    </div>
                                    {/* /.pricing-card-one */}
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-xl-5 col-lg-8 m-auto">
                                    <p className="text-center lg-mt-30">We've done it carefully and simply. Combined with the ingredients makes for beautiful landings.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <Footer />
        </>
    )
}

export default Pricing