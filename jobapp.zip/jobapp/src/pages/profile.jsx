import React from 'react'
import Sidebar from '../components/sidebar'
import Candidateprofile from '../components/candidateprofile'

const Profile = () => {
    return (
        <>
            <Sidebar sidebarOpt={2}/>
            <Candidateprofile />
        </>
    )
}

export default Profile