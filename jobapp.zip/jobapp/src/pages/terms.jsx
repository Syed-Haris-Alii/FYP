import React from 'react'
import Navbar from '../components/navbar'
import About_banner from '../components/about_banner'
import Footer from '../components/footer'

const Terms = () => {
    return (
        <>
            <Navbar />
            <About_banner title="Terms" />
            <div style={{"marginLeft":"7rem", "marginRight":"7rem"}}>
                <p className="text-lg mt-30 lg-mt-20">Write your terms here.</p>
            </div>
            <Footer />
        </>
    )
}

export default Terms