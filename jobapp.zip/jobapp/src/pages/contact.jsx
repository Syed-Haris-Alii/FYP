import React from 'react'
import Navbar from '../components/navbar'
import Footer from '../components/footer'

const Contact = () => {
    return (
        <>
            <Navbar />
            <div className="inner-banner-one position-relative">
                <div className="container">
                    <div className="position-relative">
                        <div className="row">
                            <div className="col-xl-6 m-auto text-center">
                                <div className="title-two">
                                    <h2 className="text-white">Contact Us</h2>
                                </div>
                                <p className="text-lg text-white mt-30 lg-mt-20">Find your answers</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container gy-0 pt-100">
                <div className="row gy-0 ">
                    <div className="col-sm-6">
                        <form action method="POST" name="contact" id="contact">
                            <div id="alert" />
                            <div className="errormessage" id="error" />
                            <div className="form-group">
                                <div className="controls">
                                    <label>First Name</label>
                                    <input style={{ borderRadius: 25 }} type="text" id="fname" name="fname" className="form-control" placeholder="First name" />
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="controls">
                                    <label>Last Name</label>
                                    <input style={{ borderRadius: 25 }} type="text" id="lname" name="lname" className="form-control" placeholder="Last name" />
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="controls">
                                    <label>Email</label>
                                    <input style={{ borderRadius: 25 }} required type="text" name="email" className="email form-control" id="email" placeholder="user@somewhere.com" />
                                </div>
                            </div>
                        </form>
                    </div>
                    <div className="col-sm-6">
                        <div className="form-group">
                            <div className="controls">
                                <label>Subject</label>
                                <select style={{ borderRadius: 25 }} id="subject" name="subject" className="form-control" placeholder="subject">
                                    <option value selected disabled hidden>Please select your subject</option>
                                    <option>Suggestion</option>
                                    <option>Need Assisstance</option>
                                    <option>Feedback</option>
                                    <option>Complain</option>
                                </select>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="controls">
                                <label>Message</label>
                                <textarea style={{ borderRadius: 25 }} rows={5} cols={10} type="text" id="message" name="message" className="form-control" placeholder="Type your message here..." defaultValue={""} />
                            </div>
                        </div>
                    </div>
                    <div className="col-sm-4" />
                    <div className="col-sm-4">
                        <div className="row">
                            <button style={{ margin: 'auto', marginBottom: '2%', borderRadius: 25, backgroundColor: '#2C33BF', color: 'white', marginTop:'30px' }} type="submit" id="submit" className="btn btn-secondary btn-lg btn-block" value="save" name="save">Submit</button>
                        </div>
                    </div>
                    <div className="col-sm-4" />
                </div>
            </div>

            <Footer />
        </>
    )
}

export default Contact