import React from 'react'
import Navbar from '../components/navbar'
import Footer from '../components/footer'

import { Link } from 'react-router-dom'
import About_banner from '../components/about_banner'

const Signup = () => {
    return (
        <>
            <Navbar />
            <About_banner title="Register" />
            <section className="registration-section position-relative pt-100 lg-pt-80 pb-150 lg-pb-80">
                <div className="container">
                    <div className="user-data-form">
                        <div className="text-center">
                            <h2>Create Account</h2>
                        </div>
                        <div className="form-wrapper m-auto">

                            <div className="tab-content mt-40">
                                <div className="tab-pane fade show active" role="tabpanel" id="fc1">
                                    <form action="#">
                                        <div className="row">
                                            <div className="col-12">
                                                <div className="input-group-meta position-relative mb-25">
                                                    <label>Name*</label>
                                                    <input type="text" placeholder="Rashed Kabir" />
                                                </div>
                                            </div>
                                            <div className="col-12">
                                                <div className="input-group-meta position-relative mb-25">
                                                    <label>Email*</label>
                                                    <input type="email" placeholder="rshdkabir@gmail.com" />
                                                </div>
                                            </div>
                                            <div className="col-12">
                                                <div className="input-group-meta position-relative mb-20">
                                                    <label>Password*</label>
                                                    <input type="password" placeholder="Enter Password" className="pass_log_id" />
                                                    <span className="placeholder_icon"></span>
                                                </div>
                                            </div>
                                            <div className="col-12">
                                                <div className="agreement-checkbox d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <input type="checkbox" id="remember" />
                                                        <label htmlFor="remember">By hitting the "Register" button, you agree to the <Link to="/terms-condition">Terms conditions</Link> &amp; <Link to="/privacy-policy">Privacy Policy</Link></label>
                                                    </div>
                                                </div> {/* /.agreement-checkbox */}
                                            </div>
                                            <Link to={'/dashboard'} className="col-12">
                                                <button className="btn-eleven fw-500 tran3s d-block mt-20">Register</button>
                                            </Link>
                                        </div>
                                    </form>
                                </div>

                            </div>

                            <p className="text-center mt-10">Have an account? <Link to="/login" className="fw-500" >Sign In</Link></p>
                        </div>
                    </div>
                </div>
            </section>

            <Footer />
        </>
    )
}

export default Signup