import React from 'react'
import Blogs from '../components/blogs'
import Navbar from '../components/navbar'
import About_banner from '../components/about_banner'
import Footer from '../components/footer'

const Blog = () => {
    return (
        <>
            <Navbar />
            <About_banner title="Blogs"/>
            <Blogs />
            <Footer/>   
        </>
    )
}

export default Blog