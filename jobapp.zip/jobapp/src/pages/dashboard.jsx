import React from 'react'
import Sidebar from '../components/sidebar'
import Candidatedashboard from '../components/candidatedashboard'

const Dashboard = () => {
  return (
    <>
        <Sidebar sidebarOpt={1}/>
        <Candidatedashboard/>
    </>
  )
}

export default Dashboard