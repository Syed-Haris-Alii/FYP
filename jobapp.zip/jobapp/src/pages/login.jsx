import React from 'react'
import { Link } from 'react-router-dom'

const Login = () => {
    return (
        <div className="modal-dialog modal-fullscreen modal-dialog-centered">
            <div className="container">
                <div className="user-data-form modal-content">

                    <div className="text-center">
                        <h2>Hi, Welcome Back!</h2>
                        <p>Still don't have an account? <Link to="/signup">Sign up</Link></p>
                    </div>
                    <div className="form-wrapper m-auto">
                        <form action="#" className="mt-10">
                            <div className="row">
                                <div className="col-12">
                                    <div className="input-group-meta position-relative mb-25">
                                        <label>Email*</label>
                                        <input type="email" placeholder="rshdkabir@gmail.com" />
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className="input-group-meta position-relative mb-20">
                                        <label>Password*</label>
                                        <input type="password" placeholder="Enter Password" className="pass_log_id" />
                                        <span className="placeholder_icon"></span>
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className="agreement-checkbox d-flex justify-content-between align-items-center">
                                        <div></div>
                                        <Link to="#">Forget Password?</Link>
                                    </div>
                                    <Link to={'/dashboard'} className="col-12">
                                        <button className="btn-eleven fw-500 tran3s d-block mt-20">Login</button>
                                    </Link>
                                </div>

                                <p className="text-center mt-10">Don't have an account? <Link to="/signup" className="fw-500">Sign up</Link></p>
                            </div></form>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default Login