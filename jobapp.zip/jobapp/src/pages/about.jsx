import React from 'react'
import About_banner from '../components/about_banner'
import Navbar from '../components/navbar'
import Footer from '../components/footer'
import Portal_intro from '../components/portal-intro'
import How_it_works from '../components/how-it-works'
import Feature from '../components/feature'
import Feature_3 from '../components/feature_3'

const About = () => {
    return (
        <>
            <Navbar />
            <About_banner title="About"/>
            <Feature_3 />
            <Feature />
            <How_it_works />
            <Portal_intro />
            <Footer />
        </>
    )
}

export default About