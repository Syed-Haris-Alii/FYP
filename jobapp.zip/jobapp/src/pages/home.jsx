import React from 'react'
import Navbar from '../components/navbar'
import Hero from '../components/hero'
import Category from '../components/category'
import Feature from '../components/feature'
import How_it_works from '../components/how-it-works'
import Feature_2 from '../components/feature_2'
import Blogs from '../components/blogs'
import Fancy_Banner from '../components/fancy-banner'
import Portal_intro from '../components/portal-intro'
import Footer from '../components/footer'

const Home = () => {
    return (
        <>
            <Navbar />
            <Hero />
            <Category />
            <Feature />
            <How_it_works />
            <Feature_2 />
            <Blogs />
            <Fancy_Banner />
            <Portal_intro />
            <Footer />
        </>
    )
}

export default Home