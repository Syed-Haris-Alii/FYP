import React from 'react'
import Sidebar from '../components/sidebar'
import Candidatejobalert from '../components/candidatejobalert'

const Jobalert = () => {
  return (
    <>
        <Sidebar sidebarOpt={4}/>
        <Candidatejobalert/>
    </>
  )
}

export default Jobalert