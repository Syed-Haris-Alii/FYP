import React from 'react'
import Sidebar from '../components/sidebar'
import Candidateresume from '../components/candidateresume'

const Resume = () => {
  return (
    <>
        <Sidebar sidebarOpt={3}/>
        <Candidateresume/>
    </>
  )
}

export default Resume