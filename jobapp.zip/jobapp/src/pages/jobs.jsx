import React from 'react'
import Navbar from '../components/navbar'
import Footer from '../components/footer'
import { Link } from 'react-router-dom'

const Jobs = () => {
    return (
        <>
            <Navbar />
            <div className="inner-banner-one position-relative">
                <div className="container">
                    <div className="position-relative">
                        <div className="row">
                            <div className="col-xl-6 m-auto text-center">
                                <div className="title-two">
                                    <h2 className="text-white">Job Listing </h2>
                                </div>
                                <p className="text-lg text-white mt-30 lg-mt-20 mb-35 lg-mb-20">We delivered blazing fast &amp; striking work solution</p>
                            </div>
                        </div>
                        <div className="position-relative">
                            <div className="row">
                                <div className="col-xl-9 col-lg-8 m-auto">
                                    <div className="job-search-one position-relative">
                                        <form action="">
                                            <div className="row">
                                                <div className="col-md-5">
                                                    <div className="input-box">
                                                        <div className="label">What are you looking for?</div>
                                                        <select className="nice-select lg">
                                                            <option value={1}>UI Designer</option>
                                                            <option value={2}>Content creator</option>
                                                            <option value={3}>Web Developer</option>
                                                            <option value={4}>SEO Guru</option>
                                                            <option value={5}>Digital marketer</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="input-box border-left">
                                                        <div className="label">Category</div>
                                                        <select className="nice-select lg">
                                                            <option value={1}>Web Design</option>
                                                            <option value={2}>Design &amp; Creative</option>
                                                            <option value={3}>It &amp; Development</option>
                                                            <option value={4}>Web &amp; Mobile Dev</option>
                                                            <option value={5}>Writing</option>
                                                            <option value={6}>Sales &amp; Marketing</option>
                                                            <option value={7}>Music &amp; Audio</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <button className="fw-500 text-uppercase h-100 tran3s search-btn">Search</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    {/* /.job-search-one */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <section className="job-listing-three pt-110 lg-pt-80 pb-160 xl-pb-150 lg-pb-80">
                <div className="container">
                    <div className="row">
                        <div className="col-xl-3 col-lg-4">
                            <button type="button" className="filter-btn w-100 pt-2 pb-2 h-auto fw-500 tran3s d-lg-none mb-40" data-bs-toggle="offcanvas" data-bs-target="#filteroffcanvas">
                                <i className="bi bi-funnel" />
                                Filter
                            </button>
                            <div className="filter-area-tab offcanvas offcanvas-start" id="filteroffcanvas">
                                <button type="button" className="btn-close text-reset d-lg-none" data-bs-dismiss="offcanvas" aria-label="Close" />
                                <div className="main-title fw-500 text-dark">Filter By</div>
                                <div className="light-bg border-20 ps-4 pe-4 pt-25 pb-30 mt-20">
                                    <div className="filter-block bottom-line pb-25">
                                        <Link className="filter-title fw-500 text-dark" data-bs-toggle="collapse" to="#collapseLocation" role="button" aria-expanded="false">Location</Link>
                                        <div className="collapse show" id="collapseLocation">
                                            <div className="main-body">
                                                <select className="nice-select bg-white">
                                                    <option value={0}>Washington DC</option>
                                                    <option value={1}>California, CA</option>
                                                    <option value={2}>New York</option>
                                                    <option value={3}>Miami</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.filter-block */}
                                    <div className="filter-block bottom-line pb-25 mt-25">
                                        <Link className="filter-title fw-500 text-dark" data-bs-toggle="collapse" to="#collapseJobType" role="button" aria-expanded="false">Job Type</Link>
                                        <div className="collapse show" id="collapseJobType">
                                            <div className="main-body">
                                                <ul className="style-none filter-input">
                                                    <li>
                                                        <input type="checkbox" name="JobType"  />
                                                        <label>Fixed-Price <span>7</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="JobType"  />
                                                        <label>Fulltime <span>3</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="JobType"  />
                                                        <label>Part-time (20hr/week) <span>0</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="JobType"  />
                                                        <label>Freelance <span>4</span></label>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.filter-block */}
                                    <div className="filter-block bottom-line pb-25 mt-25">
                                        <Link className="filter-title fw-500 text-dark" data-bs-toggle="collapse" to="#collapseExp" role="button" aria-expanded="false">Experience</Link>
                                        <div className="collapse show" id="collapseExp">
                                            <div className="main-body">
                                                <ul className="style-none filter-input">
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Fresher <span>5</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Intermediate <span>3</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>No-Experience <span>1</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Internship <span>12</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Expert <span>17</span></label>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.filter-block */}
                                    <div className="filter-block bottom-line pb-25 mt-25">
                                        <Link className="filter-title fw-500 text-dark" data-bs-toggle="collapse" to="#collapseSalary" role="button" aria-expanded="false">Salary</Link>
                                        <div className="collapse show" id="collapseSalary">
                                            <div className="main-body">
                                                <div className="salary-slider">
                                                    <div className="price-input d-flex align-items-center pt-5">
                                                        <div className="field d-flex align-items-center">
                                                            <input type="number" className="input-min"  readOnly />
                                                        </div>
                                                        <div className="pe-1 ps-1">-</div>
                                                        <div className="field d-flex align-items-center">
                                                            <input type="number" className="input-max"  readOnly />
                                                        </div>
                                                        <div className="currency ps-1">USD</div>
                                                    </div>
                                                    <div className="slider">
                                                        <div className="progress" />
                                                    </div>
                                                    <div className="range-input mb-10">
                                                        <input type="range" className="range-min" min={0} max={950}  step={10} />
                                                        <input type="range" className="range-max" min={0} max={1000}  step={10} />
                                                    </div>
                                                </div>
                                                <ul className="style-none d-flex flex-wrap justify-content-between radio-filter mb-5">
                                                    <li>
                                                        <input type="radio" name="jobDuration"  />
                                                        <label>Weekly</label>
                                                    </li>
                                                    <li>
                                                        <input type="radio" name="jobDuration"  />
                                                        <label>Monthly</label>
                                                    </li>
                                                    <li>
                                                        <input type="radio" name="jobDuration"  />
                                                        <label>Hourly</label>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.filter-block */}
                                    <div className="filter-block bottom-line pb-25 mt-25">
                                        <Link className="filter-title fw-500 text-dark collapsed" data-bs-toggle="collapse" to="#collapseCategory" role="button" aria-expanded="false">Category</Link>
                                        <div className="collapse" id="collapseCategory">
                                            <div className="main-body">
                                                <ul className="style-none filter-input">
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Web Design <span>15</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Design &amp; Creative <span>8</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>It &amp; Development <span>7</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Web &amp; Mobile Dev <span>5</span></label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Writing <span>4</span></label>
                                                    </li>
                                                    <li className="hide">
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Sales &amp; Marketing <span>25</span></label>
                                                    </li>
                                                    <li className="hide">
                                                        <input type="checkbox" name="Experience"  />
                                                        <label>Music &amp; Audio <span>1</span></label>
                                                    </li>
                                                </ul>
                                                <div className="more-btn"><i className="bi bi-plus" /> Show More</div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.filter-block */}
                                    <div className="filter-block bottom-line pb-25 mt-25">
                                        <Link className="filter-title fw-500 text-dark collapsed" data-bs-toggle="collapse" to="#collapseTag" role="button" aria-expanded="false">Tags</Link>
                                        <div className="collapse" id="collapseTag">
                                            <div className="main-body">
                                                <ul className="style-none d-flex flex-wrap justify-space-between radio-filter mb-5">
                                                    <li>
                                                        <input type="checkbox" name="tags"  />
                                                        <label>Web Design</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="tags"  />
                                                        <label>Squarespace</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="tags"  />
                                                        <label>Layout Design</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="tags"  />
                                                        <label>Web Development</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="tags"  />
                                                        <label>React</label>
                                                    </li>
                                                    <li>
                                                        <input type="checkbox" name="tags"  />
                                                        <label>Full Stack</label>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.filter-block */}
                                    <Link to="#" className="btn-ten fw-500 text-white w-100 text-center tran3s mt-30">Apply Filter</Link>
                                </div>
                            </div>
                            {/* /.filter-area-tab */}
                        </div>
                        <div className="col-xl-9 col-lg-8">
                            <div className="job-post-item-wrapper ms-xxl-5 ms-xl-3">
                                <div className="upper-filter d-flex justify-content-between align-items-center mb-20">
                                    <div className="total-job-found">All <span className="text-dark">7,096</span> jobs found</div>
                                    <div className="d-flex align-items-center">
                                        <div className="short-filter d-flex align-items-center">
                                            <div className="text-dark fw-500 me-2">Short:</div>
                                            <select className="nice-select">
                                                <option value={0}>Latest</option>
                                                <option value={1}>Category</option>
                                                <option value={2}>Job Type</option>
                                            </select>
                                        </div>
                                        
                                    </div>
                                </div>
                                {/* /.upper-filter */}
                                <div className="accordion-box list-style show">
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_22.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500">Fulltime</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Animator &amp; 3D Artist.</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">Spain, Bercelona</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$30-$50</span> / hour . Intermediate</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_23.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500">Fulltime</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Marketing Specialist.</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">US, New York</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$22k-$30k</span> / year . Expert</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_24.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500 part-time">Part-time</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Web Desginer.</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">Rome, Italy</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$400-$550</span> / week . Expert</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_25.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500">Fulltime</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Javascript Developer</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">Milan, Italy</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$35k-$40k</span> / year . Beginner</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_26.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500">Fulltime</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Inbound Call service.</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">UK, London</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$30-$50</span> / hour . Intermediate</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_33.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500 part-time">Part-time</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Document Typing.</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">UAE, Dubai</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$3k-$4k</span> / month . Expert</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_34.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500 part-time">Part-time</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Hotel Manager</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">AUS, Sydney</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$30-$50</span> / hour . Intermediate</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-20">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_35.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500">Fulltime</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Personal Assistant (HR)</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">USA, Alaska</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$20-$25</span> / hour . Intermediate</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                    <div className="job-list-one style-two position-relative border-style mb-30">
                                        <div className="row justify-content-between align-items-center">
                                            <div className="col-md-5">
                                                <div className="job-title d-flex align-items-center">
                                                    <Link to="job-details-v1.html" className="logo"><img src="images/lazy.svg" data-src="images/logo/media_36.png"  className="lazy-img m-auto" /></Link>
                                                    <div className="split-box1">
                                                        <Link to="job-details-v1.html" className="job-duration fw-500">Fulltime</Link>
                                                        <Link to="job-details-v1.html" className="title fw-500 tran3s">Interactive Designer.</Link>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-md-4 col-sm-6">
                                                <div className="job-location">
                                                    <Link to="job-details-v1.html">USA, California</Link>
                                                </div>
                                                <div className="job-salary"><span className="fw-500 text-dark">$250-$300</span> / week . Expert</div>
                                            </div>
                                            <div className="col-md-3 col-sm-6">
                                                <div className="btn-group d-flex align-items-center justify-content-sm-end xs-mt-20">
                                                    <Link to="job-details-v1.html" className="save-btn text-center rounded-circle tran3s me-3" title="Save Job"><i className="bi bi-bookmark-dash" /></Link>
                                                    <Link to="job-details-v1.html" className="apply-btn text-center tran3s">APPLY</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* /.job-list-one */}
                                </div>
                                
                                {/* /.accordion-box */}
                                <div className="pt-30 lg-pt-20 d-sm-flex align-items-center justify-content-between">
                                    <p className="m0 order-sm-last text-center text-sm-start xs-pb-20">Showing <span className="text-dark fw-500">1 to 20</span> of <span className="text-dark fw-500">7,096</span></p>
                                    <ul className="pagination-one d-flex align-items-center justify-content-center justify-content-sm-start style-none">
                                        <li className="active"><Link to="#">1</Link></li>
                                        <li><Link to="#">2</Link></li>
                                        <li><Link to="#">3</Link></li>
                                        <li><Link to="#">4</Link></li>
                                        <li>....</li>
                                        <li className="ms-2"><Link to="#" className="d-flex align-items-center">Last </Link></li>
                                    </ul>
                                </div>
                            </div>
                            {/* /.job-post-item-wrapper */}
                        </div>
                        {/* /.col- */}
                    </div>
                </div>
            </section>


            <Footer />
        </>
    )
}

export default Jobs