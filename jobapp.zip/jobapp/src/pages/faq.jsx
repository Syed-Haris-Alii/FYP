import React from 'react'
import Navbar from '../components/navbar'
import Footer from '../components/footer'
import Faqques from '../components/faqques'

const Faq = () => {
    return (
        <>
            <Navbar />
            <div className="inner-banner-one position-relative">
                <div className="container">
                    <div className="position-relative">
                        <div className="row">
                            <div className="col-xl-6 m-auto text-center">
                                <div className="title-two">
                                    <h2 className="text-white">Question &amp; Answers</h2>
                                </div>
                                <p className="text-lg text-white mt-30 lg-mt-20">Find your answers</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Faqques/>
            <Footer />
        </>
    )
}

export default Faq